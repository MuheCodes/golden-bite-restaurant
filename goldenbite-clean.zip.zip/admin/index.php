
<?php

require_once __DIR__ . "/auth.php";
require_once __DIR__ . "/../includes/db.php";

// CSRF protection
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Get reservation statistics
$total = $conn->query(
    "SELECT COUNT(*) AS total FROM reservations"
)->fetch_assoc()["total"];

$pending = $conn->query(
    "SELECT COUNT(*) AS total FROM reservations WHERE status = 'Pending'"
)->fetch_assoc()["total"];

$confirmed = $conn->query(
    "SELECT COUNT(*) AS total FROM reservations WHERE status = 'Confirmed'"
)->fetch_assoc()["total"];

$cancelled = $conn->query(
    "SELECT COUNT(*) AS total FROM reservations WHERE status = 'Cancelled'"
)->fetch_assoc()["total"];

// Get all reservations
$result = $conn->query(
    "SELECT * FROM reservations ORDER BY created_at DESC"
);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Golden Bite | Admin Dashboard</title>

<style>

:root {
    --gold: #c69b35;
    --dark: #17191f;
    --sidebar: #20232b;
    --background: #f5f6fa;
    --white: #ffffff;
    --text: #282b33;
    --muted: #858b98;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: var(--background);
    color: var(--text);
}

/* Main layout */

.dashboard {
    display: flex;
    min-height: 100vh;
}

/* Sidebar */

.sidebar {
    width: 250px;
    background: var(--sidebar);
    color: white;
    padding: 28px 18px;
    flex-shrink: 0;
    transition: width 0.3s ease;
}

.brand {
    font-size: 23px;
    font-weight: bold;
    color: var(--gold);
    margin-bottom: 40px;
    padding-left: 10px;
}

.brand span {
    color: white;
}

.menu-label {
    color: #858b98;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    padding: 0 10px;
    margin-bottom: 15px;
}

.sidebar a {
    display: block;
    color: #c4c7ce;
    text-decoration: none;
    padding: 14px 12px;
    margin-bottom: 7px;
    border-radius: 8px;
    transition: 0.2s;
}

.sidebar a:hover,
.sidebar a.active {
    background: #343944;
    color: white;
}

.sidebar a.active {
    border-left: 3px solid var(--gold);
}

.sidebar .logout-link {
    margin-top: 35px;
    color: #ff8585;
}

/* Main content */

.main-content {
    flex: 1;
    min-width: 0;
    padding: 30px;
}

/* Top navigation */

.topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 35px;
}

.topbar h1 {
    font-size: 25px;
}

.topbar p {
    color: var(--muted);
    font-size: 13px;
    margin-top: 7px;
}

.admin-profile {
    background: white;
    padding: 12px 18px;
    border-radius: 10px;
    box-shadow: 0 2px 8px #e6e6e6;
    font-weight: bold;
}

.admin-profile span {
    color: var(--gold);
}

/* Statistics */

.cards {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-bottom: 35px;
}

.card {
    background: white;
    padding: 23px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.04);
    border: 1px solid #eeeeee;
}

.card h3 {
    font-size: 14px;
    color: var(--muted);
    font-weight: normal;
    margin-bottom: 15px;
}

.card .number {
    font-size: 32px;
    font-weight: bold;
}

.card.total .number {
    color: var(--gold);
}

.card.pending .number {
    color: #e49b26;
}

.card.confirmed .number {
    color: #198754;
}

.card.cancelled .number {
    color: #dc3545;
}

/* Reservations section */

.section {
    background: white;
    border-radius: 12px;
    padding: 25px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.04);
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
    margin-bottom: 22px;
}

.section-header h2 {
    font-size: 19px;
}

.filters {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.filters input,
.filters select {
    padding: 11px;
    border: 1px solid #ddd;
    border-radius: 7px;
    outline: none;
}

.filters input:focus,
.filters select:focus {
    border-color: var(--gold);
}

/* Table */

.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 950px;
}

th {
    background: #f5f6fa;
    color: #777;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

th, td {
    padding: 16px 12px;
    text-align: left;
    border-bottom: 1px solid #eeeeee;
    font-size: 13px;
}

td {
    color: #454954;
}

tr:hover {
    background: #fafafa;
}

/* Status badges */

.status {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
}

.status.Pending {
    background: #fff2d8;
    color: #b7791f;
}

.status.Confirmed {
    background: #d9f5e5;
    color: #198754;
}

.status.Cancelled {
    background: #ffe0e0;
    color: #dc3545;
}

/* Action buttons */

.action-form {
    display: inline-block;
    margin: 2px;
}

button {
    padding: 8px 11px;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
    font-weight: bold;
    font-size: 11px;
}

.confirm-btn {
    background: #198754;
}

.cancel-btn {
    background: #dc3545;
}

button:hover {
    opacity: 0.8;
}

.no-results {
    text-align: center;
    padding: 30px;
    color: var(--muted);
}

/* Mobile menu button */

.menu-toggle {
    display: none;
    background: var(--dark);
    font-size: 20px;
}

/* Responsive design */

@media (max-width: 1050px) {
    .cards {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 750px) {

    .dashboard {
        display: block;
    }

    .sidebar {
        width: 100%;
        padding: 15px;
    }

    .brand {
        margin-bottom: 15px;
    }

    .sidebar nav {
        display: none;
    }

    .sidebar.open nav {
        display: block;
    }

    .menu-toggle {
        display: inline-block;
    }

    .main-content {
        padding: 20px 12px;
    }

    .topbar {
        align-items: flex-start;
    }

    .topbar h1 {
        font-size: 20px;
    }

    .admin-profile {
        font-size: 12px;
    }

    .cards {
        gap: 12px;
    }

    .card {
        padding: 17px;
    }

    .card .number {
        font-size: 25px;
    }

    .section {
        padding: 15px;
    }
}

</style>
</head>

<body>

<div class="dashboard">

    <!-- SIDEBAR -->

    <aside class="sidebar" id="sidebar">

        <div class="brand">
            GOLDEN <span>BITE.</span>
        </div>

        <button class="menu-toggle" id="menuToggle">
            ☰
        </button>

        <nav>

            <p class="menu-label">Main Menu</p>

            <a href="index.php" class="active">
                ▦ &nbsp; Dashboard
            </a>

            <a href="#reservations" onclick="document.querySelector('#reservations').scrollIntoView({behavior: 'smooth'}); return false;">
    ▤ &nbsp; Reservations
</a>

<?php if (($_SESSION["admin_role"] ?? "") === "owner"): ?>
    <a href="add_admin.php">
        + &nbsp; Add Administrator
    </a>
<?php endif; ?>

            <p class="menu-label" style="margin-top:30px;">
                Account
            </p>

            <a href="logout.php" class="logout-link">
                ↪ &nbsp; Logout
            </a>

        </nav>

    </aside>


    <!-- MAIN CONTENT -->

    <main class="main-content">

        <header class="topbar">

            <div>
                <h1>Dashboard Overview</h1>
                <p>Welcome back! Here's what's happening at Golden Bite.</p>
            </div>

            <div class="admin-profile">
                <span>●</span>
                <?= htmlspecialchars($_SESSION["admin_name"] ?? "Administrator") ?>
            </div>

        </header>


        <!-- STATISTICS -->

        <section class="cards">

            <div class="card total">
                <h3>Total Reservations</h3>
                <div class="number"><?= (int)$total ?></div>
            </div>

            <div class="card pending">
                <h3>Pending Reservations</h3>
                <div class="number"><?= (int)$pending ?></div>
            </div>

            <div class="card confirmed">
                <h3>Confirmed Reservations</h3>
                <div class="number"><?= (int)$confirmed ?></div>
            </div>

            <div class="card cancelled">
                <h3>Cancelled Reservations</h3>
                <div class="number"><?= (int)$cancelled ?></div>
            </div>

        </section>


        <!-- RESERVATIONS -->

        <section class="section" id="reservations">

            <div class="section-header">

                <h2>Customer Reservations</h2>

                <div class="filters">

                    <input
                        type="search"
                        id="searchInput"
                        placeholder="Search customer..."
                    >

                    <select id="statusFilter">
                        <option value="">All statuses</option>
                        <option value="Pending">Pending</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>

                </div>

            </div>


            <div class="table-wrapper">

                <table id="reservationTable">

                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Guests</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if ($result->num_rows > 0): ?>

                        <?php while ($row = $result->fetch_assoc()): ?>

                            <tr>

                                <td><?= (int)$row["id"] ?></td>

                                <td>
                                    <?= htmlspecialchars($row["customer_name"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row["email"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row["phone"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row["reservation_date"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row["reservation_time"]) ?>
                                </td>

                                <td>
                                    <?= (int)$row["guests"] ?>
                                </td>

                                <td>
                                    <span class="status <?= htmlspecialchars($row["status"]) ?>">
                                        <?= htmlspecialchars($row["status"]) ?>
                                    </span>
                                </td>

                                <td>

                                    <?php if ($row["status"] === "Pending"): ?>

                                        <form action="update_reservation.php"
                                              method="POST"
                                              class="action-form">

                                            <input type="hidden" name="id"
                                                   value="<?= (int)$row["id"] ?>">

                                            <input type="hidden" name="csrf_token"
                                                   value="<?= htmlspecialchars($_SESSION["csrf_token"]) ?>">

                                            <input type="hidden" name="status"
                                                   value="Confirmed">

                                            <button class="confirm-btn" type="submit">
                                                Confirm
                                            </button>

                                        </form>

                                        <form action="update_reservation.php"
                                              method="POST"
                                              class="action-form">

                                            <input type="hidden" name="id"
                                                   value="<?= (int)$row["id"] ?>">

                                            <input type="hidden" name="csrf_token"
                                                   value="<?= htmlspecialchars($_SESSION["csrf_token"]) ?>">

                                            <input type="hidden" name="status"
                                                   value="Cancelled">

                                            <button class="cancel-btn" type="submit">
                                                Cancel
                                            </button>

                                        </form>

                                    <?php else: ?>

                                        <span>—</span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="9" class="no-results">
                                No reservations have been received yet.
                            </td>
                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </section>

    </main>

</div>


<script>

// Mobile sidebar
const menuToggle = document.querySelector("#menuToggle");
const sidebar = document.querySelector("#sidebar");

menuToggle.addEventListener("click", () => {
    sidebar.classList.toggle("open");
});

// Search reservations
const searchInput = document.querySelector("#searchInput");
const statusFilter = document.querySelector("#statusFilter");
const tableRows = document.querySelectorAll("#reservationTable tbody tr");

function filterReservations() {

    const search = searchInput.value.toLowerCase();
    const status = statusFilter.value;

    tableRows.forEach(row => {

        const text = row.textContent.toLowerCase();
        const rowStatus = row.querySelector(".status")?.textContent.trim() || "";

        const matchesSearch = text.includes(search);
        const matchesStatus = !status || rowStatus === status;

        row.style.display =
            matchesSearch && matchesStatus ? "" : "none";

    });
}

searchInput.addEventListener("input", filterReservations);
statusFilter.addEventListener("change", filterReservations);

</script>

</body>
</html>
