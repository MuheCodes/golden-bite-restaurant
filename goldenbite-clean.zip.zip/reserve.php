
<?php

require_once __DIR__ . "/includes/db.php";

// Accept POST requests only
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    exit("Invalid request. Please submit the reservation form.");
}

// Collect form data
$name = trim($_POST["customer_name"] ?? "");
$email = trim($_POST["email"] ?? "");
$phone = trim($_POST["phone"] ?? "");
$date = trim($_POST["reservation_date"] ?? "");
$time = trim($_POST["reservation_time"] ?? "");
$guests = filter_var(
    $_POST["guests"] ?? null,
    FILTER_VALIDATE_INT
);
$message = trim($_POST["message"] ?? "");

// Validate customer information
$errors = [];

if ($name === "" || strlen($name) > 100) {
    $errors[] = "Please enter a valid name.";
}

if (
    !filter_var($email, FILTER_VALIDATE_EMAIL) ||
    strlen($email) > 150
) {
    $errors[] = "Please enter a valid email address.";
}

if ($phone === "" || strlen($phone) > 30) {
    $errors[] = "Please enter a valid phone number.";
}

// Validate date
$dateObject = DateTime::createFromFormat("!Y-m-d", $date);

if (
    !$dateObject ||
    $dateObject->format("Y-m-d") !== $date
) {
    $errors[] = "Please enter a valid reservation date.";
} elseif ($dateObject < new DateTime("today")) {
    $errors[] = "Reservation date cannot be in the past.";
}

// Validate time
$timeObject = DateTime::createFromFormat("!H:i", $time);

if (
    !$timeObject ||
    $timeObject->format("H:i") !== $time
) {
    $errors[] = "Please enter a valid reservation time.";
}

// Validate guests
if ($guests === false || $guests < 1 || $guests > 8) {
    $errors[] = "Guests must be between 1 and 8.";
}

if (strlen($message) > 2000) {
    $errors[] = "Your message is too long.";
}

// Show validation errors
if (!empty($errors)) {
    http_response_code(400);

    echo "<h2>Please correct these errors:</h2><ul>";

    foreach ($errors as $error) {
        echo "<li>" . htmlspecialchars($error) . "</li>";
    }

    echo "</ul>";
    echo "<a href='index.html'>Return to website</a>";
    exit;
}

// Save reservation to MySQL
try {

    $sql = "INSERT INTO reservations
        (
            customer_name,
            email,
            phone,
            reservation_date,
            reservation_time,
            guests,
            message
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "sssssis",
        $name,
        $email,
        $phone,
        $date,
        $time,
        $guests,
        $message
    );

    $stmt->execute();

    echo "<h1>Reservation received!</h1>";

    echo "<p>Thank you, " .
        htmlspecialchars($name) . "!</p>";

    echo "<p>Your reservation has been saved successfully.</p>";

    echo "<p>Status: Pending confirmation</p>";

    echo "<a href='index.html'>Return to Golden Bite</a>";

    $stmt->close();

} catch (mysqli_sql_exception $e) {

    error_log($e->getMessage());

    http_response_code(500);

    echo "<h2>Reservation could not be saved.</h2>";
    echo "<p>Please try again later.</p>";
}

?>
